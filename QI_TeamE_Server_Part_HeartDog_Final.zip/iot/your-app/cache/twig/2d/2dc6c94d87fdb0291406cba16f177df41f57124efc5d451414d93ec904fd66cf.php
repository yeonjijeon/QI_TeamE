<?php

/* signup.twig */
class __TwigTemplate_2e97d39ff38a5bf88a501aba3429dfde1f7926d1342e0c43edeb8498bc618efa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <meta charset=\"utf-8\"/>
        <title>User Sign Up</title>
        <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
        <link href='";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('slim')->baseUrl(), "html", null, true);
        echo "/css/style.css' rel='stylesheet' type='text/css'>
    </head>
    <body>
        <h1>Welcome to Ari's Site</h1>
        <div>Please sign up in the form below</div>
        ";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["fakevariable"]) ? $context["fakevariable"] : null), "html", null, true);
        echo "
<?php echo \"mike\";>

    <form action = \"/ucsd/signup/process\" method=\"post\">
        username <input type=\"text\" name-\"username\" value\"\" size=\"20\"><br />
        password <input type=\"password\" name-\"password\" value\"\" size=\"20\"><br />
        email <input type=\"email\" name-\"email\" value\"\" size=\"20\"><br />
    <input type=\"submit\" value=\"Sign me up\" />
    </form>
    </body>
</html>";
    }

    public function getTemplateName()
    {
        return "signup.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 11,  26 => 6,  19 => 1,);
    }
}
/* <html>*/
/*     <head>*/
/*         <meta charset="utf-8"/>*/
/*         <title>User Sign Up</title>*/
/*         <link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>*/
/*         <link href='{{ base_url() }}/css/style.css' rel='stylesheet' type='text/css'>*/
/*     </head>*/
/*     <body>*/
/*         <h1>Welcome to Ari's Site</h1>*/
/*         <div>Please sign up in the form below</div>*/
/*         {{fakevariable}}*/
/* <?php echo "mike";>*/
/* */
/*     <form action = "/ucsd/signup/process" method="post">*/
/*         username <input type="text" name-"username" value"" size="20"><br />*/
/*         password <input type="password" name-"password" value"" size="20"><br />*/
/*         email <input type="email" name-"email" value"" size="20"><br />*/
/*     <input type="submit" value="Sign me up" />*/
/*     </form>*/
/*     </body>*/
/* </html>*/
