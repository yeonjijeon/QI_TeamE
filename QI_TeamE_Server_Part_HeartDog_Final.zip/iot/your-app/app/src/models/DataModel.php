<?php

namespace App\Model;

final class DataModel extends BaseModel
{
    public function select_SSN_by_MAC($data) {
        $sql = "SELECT SSN FROM SENSOR WHERE MAC_ADD = ?";
        $sth = $this->db->prepare($sql);
        $sth->execute(array( $data['MAC_ADD']));
        $results = $sth->fetchAll();
        return $results;


    }


    public function insert_data_into_AQI($data)
    {
                                       
        $sql = "INSERT INTO AIR_QUALITY (
        SSN, TIMESTAMP, 
        CO, SO2, NO2, O3, PM25, TEMPERATURE,   
        AQI_CO, AQI_SO2, AQI_NO2, AQI_O3, AQI_PM25, 
        LAT, LNG )
        values
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
        $sth = $this->db->prepare($sql);
        $sth->execute(array(
            $data['SSN'], 
            $data['TIMESTAMP'], 
            $data['CO'], 
            $data['SO2'],
            $data['NO2'],
            $data['O3'], 
            $data['PM25'],
            $data['TEMPERATURE'],
            $data['AQI_CO'], 
            $data['AQI_SO2'], 
            $data['AQI_NO2'], 
            $data['AQI_O3'], 
            $data['AQI_PM25'], 
            $data['LAT'], 
            $data['LNG'],
        )); 
        $results = $sth->rowCount();
        return $results;

    }

    public function insert_into_HEART_SENSOR($data)
    {                      
        $sql = "INSERT INTO HEART_SENSOR (
        USN, TIMESTAMP, HEART_RATE)
        values
        (?, ?, ? )";
        $sth = $this->db->prepare($sql);
        $sth->execute(array(
            $data['USN'], 
            $data['TIMESTAMP'], 
            $data['HEART_RATE'], 
           
        )); 
        $results = $sth->rowCount();
        return $results;

    }



    public function select_sensor_in_lat_lng($data)
    {
        $sql ="SELECT t1.AQI_CO, t1.AQI_SO2, t1.AQI_NO2, t1.AQI_O3, t1.AQI_PM25, t2.DEVICE FROM AIR_QUALITY AS t1 INNER JOIN SENSOR AS t2 ON t1.SSN = t2.SSN WHERE ? > t1.LAT AND t1.LAT > ? AND ? > t1.LNG AND t1.LNG > ? 
        ORDER BY TIMESTAMP DESC LIMIT 1";
        
        $sth = $this->db->prepare($sql);
        $sth->execute(array($data['MINLAT'],$data['MAXLAT'],$data['MINLAT'],$data['MAXLAT']));
        $results = $sth->fetchAll();
        return $results;

    }


    public function select_data_by_usn($user)
    {
        $sql ="SELECT t1.AQI_CO, t1.AQI_SO2, t1.AQI_NO2, t1.AQI_O3, t1.AQI_PM25, t2.DEVICE FROM AIR_QUALITY AS t1 
        INNER JOIN SENSOR AS t2 ON t1.SSN = t2.SSN WHERE USN = ? 
        ORDER BY TIMESTAMP DESC LIMIT 1";
        
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['USN']));
        $results = $sth->fetchAll();
        return $results;


    }




    public function select_from_AIR_QUALITY($user)
    {   
        if($user['value']==="All") 
         $sql = "SELECT * FROM SENSOR AS S JOIN AIR_QUALITY AS A ON S.SSN = A.SSN 
         WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ? ORDER BY TIMESTAMP ASC LIMIT 1";
        else if ($user['value']==="CO_AQI")  $sql = "SELECT CO_AQI,LAT,LNG,TIMESTAMP,DEVICE,TEMPERATURE FROM SENSOR AS S JOIN AIR_QUALITY AS A on S.SSN = A.SSN WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ?  ORDER BY TIMESTAMP ASC LIMIT 1";
        else if ($user['value']==="NO2_AQI")  $sql = "SELECT NO2_AQI,LAT,LNG,TIMESTAMP,DEVICE,TEMPERATURE FROM SENSOR AS S JOIN AIR_QUALITY AS A on S.SSN = A.SSN WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ?  ORDER BY TIMESTAMP ASC LIMIT 1";
        else if ($user['value']==="O3_AQI")  $sql = "SELECT O3_AQI,LAT,LNG,TIMESTAMP,DEVICE,TEMPERATURE FROM SENSOR AS S JOIN AIR_QUALITY AS A on S.SSN = A.SSN WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ?  ORDER BY TIMESTAMP ASC LIMIT 1";
        else if ($user['value']==="SO2_AQI")  $sql = "SELECT SO2_AQI,LAT,LNG,TIMESTAMP,DEVICE,TEMPERATURE FROM SENSOR AS S JOIN AIR_QUALITY AS A on S.SSN = A.SSN WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ?  ORDER BY TIMESTAMP ASC LIMIT 1";
        else if ($user['value']==="PM2.5_AQI")  $sql = "SELECT PM2.5_AQI,LAT,LNG,TIMESTAMP,DEVICE,TEMPERATURE FROM SENSOR AS S JOIN AIR_QUALITY AS A on S.SSN = A.SSN WHERE ? > LAT AND LAT > ? AND ? > LNG AND LNG > ?  ORDER BY TIMESTAMP ASC LIMIT 1";
        else $sql = null;
        
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['north'],$user['south'],$user['east'],$user['west'])); 
        $results = $sth->fetchAll();
        return $results;
    }

    public function select_from_HEART_SENSOR($user)
    {     
         $sql = "SELECT HEART_RATE, TIMESTAMP FROM HEART_SENSOR WHERE USN = ? ORDER BY TIMESTAMP desc";
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['USN'])); 
        $results = $sth->fetchAll();
        return $results;
    }


    public function select_historical_data_from_airquality($user) {
        
        $sql = "SELECT SSN,CO,SO2, NO2, O3, PM25, TEMPERATURE, LAT, LNG, TIMESTAMP
         FROM AIR_QUALITY WHERE SSN = ? AND TIMESTAMP BETWEEN ? AND ? LIMIT 1000";
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['SSN'],$user['FROM_TS'],$user['TO_TS']));
        $results = $sth->fetchAll();
        return $results;
    }

    public function select_historical_data_from_heartrate($user) {
        
        $sql = "SELECT HEART_RATE, TIMESTAMP
         FROM HEART_SENSOR WHERE USN = ? AND TIMESTAMP BETWEEN ? AND ? LIMIT 1000";
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['USN'],$user['FROM_TS'],$user['TO_TS']));
        $results = $sth->fetchAll();
        return $results;
    }


    
    public function select_historical_data_from_airquality_table($user) {
        
        $sql = "SELECT * FROM AIR_QUALITY  where SSN=? AND TIMESTAMP > ? ORDER BY  TIMESTAMP DESC limit 1000";
        $sth = $this->db->prepare($sql);
        $sth->execute(array($user['SSN'],$user['historical_interval']));
        $results = $sth->fetchAll();
        return $results;
    }






}
