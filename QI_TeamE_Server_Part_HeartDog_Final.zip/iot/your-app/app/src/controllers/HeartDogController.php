<?php
namespace App\Controller;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;




final class HeartDogController extends BaseController
{
  protected $logger;
  protected $SensorModel;
  protected $view;

  public function __construct($logger, $SensorModel, $view)
  {
    $this->logger = $logger;
    $this->SensorModel = $SensorModel;
    $this->view = $view;
  }
  


  public function dogregister(Request $request, Response $response,$args){
    $this->view->render($response, 'dog_register.twig');
    return $response;
  }

  

    public function handleSignUp(Request $request, Response $response, $args) {
         echo "I am going to check the database for your email address";
         var_dump($_POST);
         print_r($_POST);
         $email_found = 1;
         if ($email_found){$status = "error";}
         else $status = "good";
         // write sql query
         // if $email found, then write error message
         // if $email not found, then save to database and then send email

         $this->view->render($response, 'hendlesignup.twig', ['status'=>$status, 'post' => $_POST]);
           return $response;
    }









public function dogregister_process(Request $request, Response $response, $args) 
{ 

  try {
    $user['DNAME'] = $_POST["DNAME"];
    $user['DSIZE'] = $_POST["DBIRTH"];
    $user['DGENDER'] = $_POST["DGENDER"];
    $user['BREED'] =  $_POST["BREED"];
        
    $query_results =  $this->HeartDogModel->insert_dog($user);

      } catch (PDOException $e) { // insert 실패 (커뮤니케이션 오류)
          $this->view->render($response, 'dog_register.twig', ['error_message'
          => 'PDOException. Try again please.', 'result_code' => 1]);
          return $response;
    }
}
}